self.__precacheManifest = [
  {
    "revision": "0dd8e7a75d7f0f63d76b264c279f3680",
    "url": "/static/media/trash.0dd8e7a7.svg"
  },
  {
    "revision": "8f082c85c64a01c2a5f8",
    "url": "/static/css/main.e9faf2f1.chunk.css"
  },
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "5bee74caefdf9d0a834915f6c8eeb259",
    "url": "/static/media/notification.5bee74ca.svg"
  },
  {
    "revision": "b87f606a08e2de17a40b",
    "url": "/static/js/2.b87f606a.chunk.js"
  },
  {
    "revision": "8f082c85c64a01c2a5f8",
    "url": "/static/js/main.8f082c85.chunk.js"
  },
  {
    "revision": "c0d3c94cd6112550c51d7d1ed13b9da1",
    "url": "/static/media/notification.c0d3c94c.eot"
  },
  {
    "revision": "0b4ac1dc75df35e169b70d7719afe4cc",
    "url": "/static/media/notification.0b4ac1dc.ttf"
  },
  {
    "revision": "651771e1df95c807c99608188d0a4287",
    "url": "/static/media/notification.651771e1.woff"
  },
  {
    "revision": "b87f606a08e2de17a40b",
    "url": "/static/css/2.31f885e5.chunk.css"
  },
  {
    "revision": "5d76151340fac70b5cdd78a02ecebbd5",
    "url": "/index.html"
  }
];